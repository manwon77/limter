define(['jquery','easing'],function($,easing){
	var resolution = {
		init : function(){			

			/*
			var grid = document.querySelector('.grid');
			var msnry = new Masonry( grid, {
				columnWidth: 120,
				itemSelector: '.grid-item'
			});

			eventie.bind( grid, 'click', function( event ) {
				// don't proceed if item content was not clicked on
				var target = event.target;
					if ( !classie.has( target, 'grid-item-content' )  ) {
					  return;
					}
				var itemElem = target.parentNode;
				classie.toggleClass( itemElem, 'is-expanded' );

				msnry.layout();
			});
			*/

		}	
	}
	return resolution;
});